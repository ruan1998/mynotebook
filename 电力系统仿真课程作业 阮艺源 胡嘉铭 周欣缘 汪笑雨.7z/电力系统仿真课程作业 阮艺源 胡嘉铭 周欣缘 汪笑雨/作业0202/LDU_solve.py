import numpy as np

def LDU(A):  #LDU分解函数
    size=A.shape[0]
    B=A.copy()  #直接的=会将地址赋值，要重新建立一个矩阵，要用copy()
    L= np.zeros((size, size))
    D= np.zeros((size, size))
    U= np.zeros((size, size))
    D[0][0]=B[0][0]
    for i in range(size):
        L[i][i] = 1
        U[i][i] = 1
    for i1 in range(size):
        for i2 in range(i1,size):
            for j in range(i1+1,size):
                if(i2==i1):
                    U[i2][j]=B[i2][j]/D[i2][i2]
                if(i2>i1):
                    B[i2][j]=B[i2][j]-B[i2][i1]*U[i1][j]
            if(i2==i1+1):
                D[i2][i2] = B[i2][i2]
            if (i2>i1):
                L[i2][i1]=B[i2][i1]/D[i1][i1]
    return L,D,U

def LDU_store(A):  #三角存储检索，不是实际的坐标
    L,D,U=LDU(A)
    size=A.shape[0]
    L_value=[]
    L_row=[]
    L_column=[]
    D_value=[]
    U_value=[]
    U_row=[]
    U_column=[]
    for i in range(1,size):
        for j in range(i):
            if(L[i][j]!=0):
                L_value.append(L[i][j])
                L_row.append(i)
                L_column.append(j)
    for i in range(size-1):
        for j in range(i+1,size):
            if(U[i][j]!=0):
                U_value.append(U[i][j])
                U_row.append(i)
                U_column.append(j)
    for i in range(size):
        D_value.append(D[i][i])
    return (L_value,L_row,L_column),(D_value),(U_value,U_row,U_column)

def front(L,b):  #前代,用LDU系数存储
    size=b.shape[0]
    z=np.zeros((size,1))
    for i in range(len(b)):
        sum = 0
        if L[1].count(i)!=0:
            for j in range(L[1].index(i),L[1].index(i)+L[1].count(i)):
                sum+=L[0][j]*z[L[2][j],0]
        z[i,0]=b[i]-sum
    return z


def front1(L,b):  #前代，没用LDU系数存储
   size = b.shape[0]
   z=np.zeros((size,1))
   sum_list=[]
   for i in range(len(b)):
       sum=0
       for j in range(i):
           if(i>0):
               sum+=L[i][j]*z[j,0]
       sum_list.append(sum)
       z[i,0] = b[i,0]-sum_list[i]
   return z


def mid(D,z):  #规格化，用LDU系数存储
    size = z.shape[0]
    y = np.zeros((size,1))
    for i in range(len(D)):
        y[i,0]=z[i,0]/D[i]
    return y


def mid1(D,z):  #规格化，没用LDU系数存储
   size = z.shape[0]
   y = np.zeros((size,1))
   for i in range(D.shape[0]):
       y[i,0]=z[i,0]/D[i][i]
   return y

def back(U,y):  #回代，用LDU系数存储
    size=y.shape[0]
    x=np.zeros((size,1))
    for i in range(size):
        sum = 0
        if U[1].count(size-i-1)!=0:
            for j in range(U[1].index(size-i-1),U[1].index(size-i-1)+U[1].count(size-i-1)):
                sum+=U[0][j]*x[U[2][j],0]
        x[size-i-1,0]=y[size-i-1,0]-sum #现在x是从x[size-1]到x[0]
        x_reverse=np.zeros((size,1))
        for i in range(size):
            x_reverse[i,0]=x[size-1-i,0]
    return x_reverse

def back1(U,y):  #回代，没用LDU系数存储
   size=y.shape[0]
   x = np.zeros((size, 1))
   sum_list=[]
   for i in range(U.shape[0]):
       sum=0
       for j in range(i):
           if(i>0):
               sum+=U[size-i-1][size-j-1]*x[size-j-1,0]
       sum_list.append(sum)
       x[size-i-1,0] = y[size-i-1,0]-sum_list[i]
       x_reverse = np.zeros((size, 1))
       for i in range(size):
           x_reverse[i,0] = x[size - 1 - i,0]
   return x_reverse

def solve(A,b):  #求解AX=b
    L,D,U=LDU_store(A)
    X=back(U,mid(D,front(L,b)))
    return X


def solve_Sparse_vector(A,b,x_index):  #稀疏向量法，x_index为所需求解的特定变量
    L,D,U=LDU(A)
    y=mid1(D, front1(L, b))
    list_delete_x=[]
    for i in range(x_index,len(b)):
        if not any(U[x_index-1:i,i]): #若第i个元素和x_index无关，则U[x_index-1:i][i]应全为0;
            list_delete_x.append(i)
    for i in list_delete_x:
        U = np.delete(U, i, axis=0)
        U = np.delete(U, i, axis=1)
        y = np.delete(y, i, axis=0)
    for i in range(x_index-1):
        U = np.delete(U, 0, axis=0)  #每次循环都删第一行第一列，循环后则把原矩阵的前k行k列都删去了
        U = np.delete(U, 0, axis=1)
        y = np.delete(y, 0, axis=0)
    x=back1(U,y)
    return x[0]

A=np.array([[2,0,0,0,0,0,1,0,0,0,0,1],
             [0,2,0,0,1,0,0,0,1,0,0,0],
             [0,0,2.,0,0,1,0,0,1,0,0,0],
             [0,0,0,2,0,0,1,0,0,1,0,0],
             [0,1,0,0,2,0,0,0,0,0,0,1],
             [0,0,1,0,0,2,0,0,0,1,0,0],
             [1,0,0,1,0,0,2,0,0,0,0,0],
             [0,0,0,0,0,0,0,2,1,0,1,0],
             [0,1,1,0,0,0,0,1,2,0,0,0],
             [0,0,0,1,0,1,0,0,0,2,1,0],
             [0,0,0,0,0,0,0,1,0,1,2,1],
             [1,0,0,0,1,0,0,0,0,0,1,2]])
b=np.array([[4],[4],[4],[4],[4],[4],[4],[4],[5],[5],[5],[5]])

print("解得的X为：")
print(solve(A,b))
print("需要求解的特定变量的值为：")

print(solve_Sparse_vector(A,b,3))
#solve_Sparse_vector函数的第三个参数则为需求解的某个特定变量的下标；如需求x3，则设置为3
